package Exercise6;

public class AddTop implements Step{
    @Override
    public String toString() {
        return "Top";
    }

    @Override
    public void perform(Furniture furniture) {
        furniture.add("Top");
    }

}
