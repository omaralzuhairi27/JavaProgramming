package Exercise6;

public interface Step {
    void perform(Furniture furniture);
}
