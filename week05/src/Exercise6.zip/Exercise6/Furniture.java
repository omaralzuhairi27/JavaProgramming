package Exercise6;

public interface Furniture {

     void add(String part);
}
