package Exercise5;

import java.util.Scanner;

public class MasterCard extends CreditCard {
    @Override
    public String getName() {
        return "Master Card";
    }

    @Override
    public Long getDigitNumber() {
        Scanner scanner = new Scanner(System.in);
        Long number = scanner.nextLong();
        if (isValid(number)) {
            return number;
        }
        return scanner.nextLong();
    }

    @Override
    public Boolean isValid(Long number) {

        String digitLength=Long.toString(number);
        if(digitLength.length()==16&&digitLength.startsWith("51")||digitLength.startsWith("52")||digitLength.startsWith("53")||digitLength.startsWith("54")||digitLength.startsWith("55")){
            return true;
        }
        return false;
    }


    }

