package Exercise5;

public class CreditCardApplication {
    public static void main(String[] args) {
        LuhnAlgorithm luhnAlgorithm = new LuhnAlgorithm();

        AmericanExpress americanExpress  = new AmericanExpress();
        Long num=americanExpress.getDigitNumber();


        if(americanExpress.isValid(num)|| luhnAlgorithm.validateCardNumber(num)){
            System.out.println("valid");
        }else {
            System.out.println("invalid");
        }

       // luhnAlgorithm.validateCardNumber(378282246310005l);
    }
}
